"use strict";
/* HIDDEN DINOX ACADEMY — подключение к существующему серверу AI BOOST.
   Вызывается из server.js одной строкой; старые маршруты не меняются. */
const path = require("path");
const { mountAcademyApi } = require("./api");
const { createAcademyPostback } = require("./postback");

function attachAcademy({ app, express, admin, db, env = process.env, log = console, publicDir }) {
  // IP отправителя за прокси Render: включается явно (TRUST_PROXY=1), нужен только для POSTBACK_ALLOWED_IPS
  if (env.TRUST_PROXY) app.set("trust proxy", /^\d+$/.test(env.TRUST_PROXY) ? Number(env.TRUST_PROXY) : env.TRUST_PROXY);
  // 1) API академии. Без Firebase — честный ответ 503, доступ закрыт.
  const verifyIdToken = db && admin && admin.auth ? t => admin.auth().verifyIdToken(t) : null;
  mountAcademyApi(app, express, { db, verifyIdToken, log });

  // 2) Статика академии: HTML без кеша, остальное — короткий кеш (адреса файлов версионированы)
  app.use("/academy", express.static(path.join(publicDir, "academy"), {
    index: "index.html",
    setHeaders(res, p) {
      res.setHeader("Cache-Control", p.endsWith(".html") ? "no-cache" : "public, max-age=3600");
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Referrer-Policy", "same-origin");
    }
  }));

  // 3) Обработчик postback для академии (вызывается из существующего /postback)
  const postback = createAcademyPostback({ db, env, log });
  const pc = postback.config;
  if (!pc.enabled) log.warn && log.warn("⚠️ academy: обработка postback выключена (ACADEMY_POSTBACK_ENABLED≠1) — подтверждения не записываются");
  else if (!pc.secretConfigured && !pc.ipListConfigured) log.warn && log.warn("⚠️ academy: проверка источника postback не настроена — подтверждения академии не записываются");
  if (pc.secretTooShort) log.warn && log.warn("⚠️ academy: POSTBACK_SECRET короче допустимого — считается ненастроенным");
  return { postback };
}

/* Закрывает публичную раздачу файлов ботов из public/bot (сами файлы не трогаем: require читает их с диска).
   Путь декодируется и нормализуется так же, как это делает раздача статики, чтобы /%62ot/… или /x/../bot/… не обходили запрет. */
const BLOCKED_PREFIXES = ["/bot"];
function isBlockedPath(rawPath) {
  let p;
  try { p = decodeURIComponent(rawPath); } catch (e) { return true; }
  p = path.posix.normalize(p.replace(/\\/g, "/")).toLowerCase();
  return BLOCKED_PREFIXES.some(b => p === b || p.startsWith(b + "/"));
}
function blockPrivateStatic(app) {
  app.use((req, res, next) => (isBlockedPath(req.path) ? res.status(404).send("Not found") : next()));
}

module.exports = { attachAcademy, blockPrivateStatic, isBlockedPath };
